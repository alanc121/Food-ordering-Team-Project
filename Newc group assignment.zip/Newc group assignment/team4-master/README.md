# Team 4

## Viewing the website
- [Main website](http://csc8019-04.cs.ncl.ac.uk/public/pages/home.php)
<br>You may try to place an order by creating your own account or by using the login details:
    >email: daniel@mail.com<br>
    >password: password
- [Analytics portal](http://csc8019-04.cs.ncl.ac.uk/staff/stafflogin.php)
<br>Use the dummy login details:
    >username: admin<br>
    >password: cavallo123

- [Driver portal](http://csc8019-04.cs.ncl.ac.uk/staff/driverlogin.php)
<br>Use the dummy login details:
    >username: driver<br>
    >password: vroomvroom

- For an overview of the navigation, please refer to the [navigation documentation](Navigating_around_the_website.docx)

## Code structure
- `/public/pages` contains the source code for all pages which would be visible to customers
- `/public/functionality` contains functionality modules used in public pages
- `/public/css` contains styling for public pages
- `/public/common` contains header and footer code which are displayed on all public pages
- `/staff/` contains staff pages (analytics and driver portals), only accessible after logging in
- `/staff/functionality` contains functionality modules for staff pages
- `/config/` contains a php module which establishes a connection to the database using 'mysqli'

## External libraries used
- [jQuery](https://jquery.com/) v3.6.0
- [Chart.js](https://www.chartjs.org/) v2.9.4
- [Bootstrap](https://getbootstrap.com/docs/3.3/) v3.3.7

## Other sources
- icons : [Google Fonts](https://fonts.google.com/icons)
- favicon : [twemoji](https://twemoji.twitter.com/) & [favicon.io](https://favicon.io/)
- postcode generator : [FreeMapTools](https://www.freemaptools.com/find-uk-postcodes-inside-radius.htm)

