<?php
// Database connection information (Manon)
$servername = "cs-db.ncl.ac.uk";
$username = "csc8019_team04";
$password = "Pop9Limb2How";
$dbname = "csc8019_team04";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname, 3306);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}