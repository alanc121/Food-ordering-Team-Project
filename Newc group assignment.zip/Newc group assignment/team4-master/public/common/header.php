<?php
session_start();

include '../functionality/timeChecker.php';

$cssDir = "../css/"; //folder where all CSS files live

//Link each page to its CSS file
$styles = [
    'home' => 'home.css',
    'menu' => 'menu.css',
    'customerregistration' => 'customerregistration.css',
    'ordercomplete' => 'ordercomplete.css'
];

// If shop is closed disable the basket's checkout button (added by Manon)
$disabled_attribute = "";
if (!$shop_is_open) {
    $disabled_attribute = "disabled";
}

// Change account button depending on whether user is logged in (added by Manon)
$account_button_link = "customerlogin.php";
$account_button_text = "Log in";
if ($_SESSION["customer_login"] === TRUE) {
    $account_button_link = "customerlogout.php";
    $account_button_text = "Log out";
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Cavallo</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../img/favicon.png">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../css/header.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $cssDir . "header.css" ?>">
    <!-- CSS common to all pages -->
    <link rel="stylesheet" type="text/css" href="<?php echo $cssDir . "bootstrap-337.min.css" ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo $cssDir . "group_style.css" ?>">
    <!-- CSS, specific to the current page -->
    <link rel="stylesheet" type="text/css" href="<?php echo $cssDir . $styles[$this_page] ?>">
    <script src="https://kit.fontawesome.com/1b9e582545.js" crossorigin="anonymous"></script>

    <link href="https://fonts.googleapis.com/css2?family=Vollkorn:wght@600&display=swap" rel="stylesheet">

    <script src="../functionality/orderType.js"></script>
</head>

<!-- Confirmation pop added by Danyang -->
<?php ob_start(); ?>
<SCRIPT LANGUAGE=javascript>
    function del() {
        var msg = "Are you sure to empty the basket？";
        if (confirm(msg) == true) {
            return true;
        } else {
            return false;
        }
    }
</SCRIPT>


<body>

    <header>
        <div class="row">
            <div class="column">
                <a class="pull-left" href="home.php">
                    <img src="../img/Cavallo.JPG" alt="Cavallo Logo" title="Cavallo Logo" width=240px height=110px>
                </a>
            </div>

            <div class="column">
                <nav class="buttons">
                    <ul>
                        <li>
                            <button id="account_button" type="button" onclick="window.location.href='<?= $account_button_link ?>';" aria-label="login or logout">
                                <?= $account_button_text ?>
                                <img src="../img/outline_account_circle_black_36dp.png" alt="account icon">
                            </button>
                        </li>

                        <li>
                            <div class="Dropdown" id="basket-dropdown">
                                <!-- Create dropdown sidebar menu which appears when you click basket button  - Dylan-->
                                <input type="checkbox" id="box" />
                                <label>
                                    <label for="box" id="label2" aria-label="open basket">
                                        <img src="../img/outline_shopping_cart_black_36dp.png" alt="shopping cart icon" />
                                    </label>
                                    <div class="dropdown-visible" style="overflow-y:scroll;">
                                        <label for="box" id="label3"> &#10005 </label>

                                        <h2 style="font-family: Vollkorn, serif; font-size:200%"> Basket</h2>
                                        <form method="POST" action="checkout.php">
                                            <select id="basket-order-type-select" name="ordertype" aria-label="select order type">
                                                <option value="delivery">Delivery</option>
                                                <option value="collection">Collection</option>
                                            </select>

                                            <br>

                                            <?php
                                            // author by Danyang and Zhongyuan
                                            require_once '../functionality/cart/cartfunction.php';
                                            $shop_car = unserialize($_COOKIE['cart']);
                                            if (empty($shop_car)) {
                                                echo '<h4 id="basket__total">Basket is empty</h4>';
                                            } else {
                                                // show products
                                                $key = array_keys($shop_car);
                                                for ($i = 0; $i < count($shop_car); $i++) {
                                                    $basket_flavor = $shop_car[$key[$i]][0];
                                                    $basket_size = $shop_car[$key[$i]][2];
                                                    $basket_unitPrice = unitPrice($shop_car[$key[$i]][0], $shop_car[$key[$i]][2]);
                                                    $basket_quantity = $shop_car[$key[$i]][1];
                                                    $basket_dairyfree = $shop_car[$key[$i]][3];

                                            ?>
                                                    <div class="showcase" id="basket_showcase">
                                                        <!-- showcase Begin -->
                                                        <table>
                                                            <!-- table Begin -->
                                                            <tr>
                                                                <!-- tr Begin -->
                                                                <td id=td-4>
                                                                    <img class="img-responsive" src="../img/<?php echo $basket_flavor; ?>.jpg" alt="<?php echo $basket_flavor; ?> image" title="<?php echo $basket_flavor; ?>" height="60" width="60">
                                                                </td>
                                                                <td id=td-5>
                                                                    <ul>
                                                                        <li><?php echo "<a href='../pages/product.php?flavour=$basket_flavor'>"; ?><strong><?php echo "$basket_dairyfree" . ' ' . "$basket_flavor"; ?></strong></a></li>
                                                                        <li class="text-muted"><?php echo $basket_size; ?></li>
                                                                        <li class="text-muted">£<?php echo $basket_unitPrice; ?></li>
                                                                    </ul>
                                                                </td>
                                                                <td id=td-6>
                                                                    <ul>
                                                                        <li aria-label="increase item quantity"><?php echo '<a href="../pages/menu.php?add=' . $key[$i] . '">+</a><br />'; ?></li>
                                                                        <li><?php echo $basket_quantity; ?></li>
                                                                        <li aria-label="decrease item quantity"><?php echo '<a href="../pages/menu.php?del=' . $key[$i] . '">-</a><br />'; ?></li>
                                                                    </ul>
                                                                </td>
                                                            </tr><!-- tr Finish -->
                                                        </table><!-- table Finish -->
                                                    </div><!-- showcase Finish -->

                                            <?php }
                                                // Total price
                                                $basket_totalPrice = totalPrice($shop_car);
                                                echo "<br/><h2 id='basket__total' style= 'font-family: Vollkorn, serif '; >Total: £$basket_totalPrice </h2>";
                                                if (isset($_GET['del'])) {
                                                    $del = $_GET['del'];
                                                    if ($_GET['del'] == $del) {
                                                        delQuantity($shop_car, $del);
                                                        echo "<script>location.href='" . $_SERVER["HTTP_REFERER"] . "'</script>";
                                                    }
                                                }
                                                if (isset($_GET['add'])) {
                                                    $add = $_GET['add'];
                                                    if ($_GET['add'] == $add) {
                                                        addQuantity($shop_car, $add);
                                                        echo "<script>location.href='" . $_SERVER["HTTP_REFERER"] . "'</script>";
                                                    }
                                                }
                                                echo '<br /><a href="../pages/menu.php?clean=all" class="btn btn-primary" id="basket__btn" onclick="javascript:return del()">Empty basket </a><br />';
                                                if (isset($_GET['clean'])) {
                                                    if ($_GET['clean'] == 'all') {
                                                        delAll();
                                                    }
                                                }
                                            }
                                            ob_end_flush();
                                            ?>
                                            <?php
                                            echo '<input class="btn btn-primary" id="basket__btn" type="submit" value="Checkout"' . $disabled_attribute . '>';
                                            ?>
                                        </form>

                                    </div>
                                </label>
                            </div>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
        <!-- added by Manon -->
        <?php
        if (!$shop_is_open) { ?>

            <div id="shop-closed-banner">
                <img id="shop-closed-icon" src="../img/outline_schedule_white_24dp.png" alt="clock icon">
                <p>Our shop is currently closed and will reopen at 11 am. Feel free to browse our menu until then!</p>
            </div>
        <?php }
        ?>

    </header>

    <main class=" <?php $this_page ?>">