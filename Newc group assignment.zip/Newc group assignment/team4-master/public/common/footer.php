</main>

<!-- Style by Zhongyuan -->
<div id="footer">
	<!-- #footer Begin -->
	<div class="container">
		<!-- container Begin -->
		<div class="row">
			<!-- row Begin -->
			<div class="col-md-12">
				<!-- col-md-12 Begin -->
			</div>

			<div class="col-md-3">
				<!-- col-md-5 Begin -->
				<h2>Opening hours:</h2>
				<ul id="opening-times">
					<li>Monday: 11:00 - 18:00</li>
					<li>Tuesday: 11:00 - 18:00</li>
					<li>Wednesday: 11:00 - 18:00</li>
					<li>Thursday: 11:00 - 18:00</li>
					<li>Friday: 11:00 - 18:00</li>
					<li>Saturday: 11:00 - 18:00</li>
					<li>Sunday: 11:00 - 18:00</li>
				</ul>
			</div><!-- col-md-5 Finish -->

			<div class="col-md-4">
				<!-- col-md-1 Begin -->
			</div>

			<div class="col-md-5">
				<!-- col-md-5 Begin -->
				<h2>Where to find us:</h2>
				<ul id="find-us">
					<li><strong>Cavallo</strong></li>
					<li>Avenue Crescent</li>
					<li>Seaton Delaval</li>
					<li>Northumberland</li>
					<li>NE25 0DN</li>
				</ul>
			</div><!-- col-md-5 Finish -->
		</div><!-- row Finish -->
	</div><!-- container Finish -->
</div><!-- #footer Finish -->

</body>

</html>

<?php
// Record current page url for redirecting user after login (added by Manon)
if ($this_page == "product") {
	$_SESSION["redirect_url"] = "menu.php";
} elseif ($this_page != "customerlogin" && $this_page != "customerregistration") {
	$_SESSION["redirect_url"] = $this_page . ".php";
}
?>

<!-- AJAX for hiding basket on checkout and ordercomplete pages - added by Manon adapted from Kimberly's jQuery code -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script>
	$(function() {
		$(document).ready(function() {
			var page = '<?php echo "$this_page"; ?>';
			if (page == "checkout" || page == "ordercomplete") {
				$("#basket-dropdown").hide();
			} else {
				$("#basket-dropdown").show();
			}
		})
	})
</script>

<script>
	// Added by Manon
	// Store order type as cookie
	$(function() {
		$("#basket-order-type-select").change(function() {
			var option = $("#basket-order-type-select").val();
			if (option === "delivery") {
				setOrderTypeCookie("delivery");
			}
			if (option === "collection") {
				setOrderTypeCookie("collection");
			}
		})
	})
	// Select the order type if it has already been chosen
	orderType = getOrderTypeCookie();
	if (orderType === "delivery") {
		$("#basket-order-type-select").val("delivery");
	}
	if (orderType === "collection") {
		$("#basket-order-type-select").val("collection");
	}
</script>