<?php
// Authors: Josh & Alan

include '../../config/connect.php';
include 'cart/cartfunction.php';

session_start();

// Redirects customer to login page if they are not logged in -- Danyang
$is_flag=$_SESSION["customer_login"];
if($is_flag!=true){
     echo '<script>alert("Please login in");window.location.href="../pages/customerlogin.php"</script>';
     exit;
     }
else{
    //creates a php array representing the cart from the stored cookies
    $shop_car = unserialize($_COOKIE['cart']);

    $postcode = $_SESSION['postcode'];
    $house_number = $_SESSION['housenumber'];
    $street_name = $_SESSION['streetname'];

	executePayment();

    $conn->close();
}
//Main function which should be executed when the 'Checkout with HorsePay' button is pressed
function executePayment() {

	global $shop_car;

	//url to send HorsePay API requests to
	$url = 'http://homepages.cs.ncl.ac.uk/daniel.nesbitt/CSC8019/HorsePay/HorsePay.php';

	// sets the timezone for date based on the given location
	date_default_timezone_set('Europe/London');

	$customer_ID = $_SESSION["customerID"];
	$order_method = $_SESSION['checkout-order-type-select'];

	$date = date('d/m/Y');
	$time = date('H:i');

	$data = array(
	'storeID' => 'Team04', //value is constant as it is our team identifier
	'customerID' => $customer_ID, //use customer_ID from current session
	'date' => $date, //Uses current date in appropriate format
	'time' => $time, //Uses current time in 24hr format
	'timeZone' => date('T'), //Uses current timezone
	'transactionAmount' => totalPrice($shop_car), //gets price from shop_car
	'currencyCode' => 'GBP' //value is constant as we can assume all transactions are in GBP
	);

	// creates a json object from the php array above
	$data = json_encode($data);

	// use key 'http' even if you send the request to https://...
	$options = array(
		'http' => array(
			'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
			'method'  => 'POST',
			'content' => $data
		)
	);
	$context  = stream_context_create($options);
	$result = file_get_contents($url, false, $context);

	//converts json object response to a php array and saves the payment status to a variable
	$response_array = json_decode($result, true);
	$payment_status = $response_array['paymetSuccess']['Status'];

	// changing date format so that it is accepted by the database
	$date = date('Y-m-d');

	// Creates order and sends user to order completion page if the transaction is successful
	// If transaction fails, the user is alerted to the reason and remains on the checkout page
	if ($payment_status === TRUE) {

		// Decides if order is collection or delivery by checking the contents of the postcode session variable
		if($order_method === 'delivery') {
			$_SESSION['newOrderID'] = createNewOrder($customer_ID, createNewDelivery(), totalPrice($shop_car), $time, $date);
		} else {
			$_SESSION['newOrderID'] = createNewOrder($customer_ID, 'NULL', totalPrice($shop_car), $time, $date);
		}

		insertItemsIntoOrderedItems($_SESSION['newOrderID']);
		echo "<script>window.location.href = '../pages/ordercomplete.php'</script>";
		return TRUE;
	} else {
		if ($response_array['paymetSuccess']['reason'] == "transaction declined by bank") {
			echo "<script>alert('Transaction was declined by bank, please confirm with bank and try again.'); window.location.href = '../pages/checkout.php'</script>";
			return FALSE;
		} else if ($response_array['paymetSuccess']['reason'] == "internal error with HorsePay server") {
			echo "<script>alert('There is an issue with HorsePay servers at this moment, please try again later.'); window.location.href = '../pages/checkout.php'</script>";
			return FALSE;
		}
		echo "Payment has failed for an unknown reason";
		return FALSE;
	}
}

//Inserts items from shopping cart into the database
function insertItemsIntoOrderedItems($order_ID) {

	global $conn;
	global $shop_car;
	$key = array_keys($shop_car);

	for ($i = 0; $i < count($shop_car); $i++) {

		//Reads information from shopping cart for insertion into ordered_items
		$flavour = $shop_car[$key[$i]][0];
		$quantity = $shop_car[$key[$i]][1];
		$size = $shop_car[$key[$i]][2];
		$dairy_free = $shop_car[$key[$i]][3];

		if($dairy_free == "DairyFree"){
			$dairy_free = 1;
		} else {
			$dairy_free = 0;
		}

		//Gets the correct flavour_ID for insertion into orderedItems
		$stmt_flav = $conn->stmt_init();
		if($stmt_flav = $conn->prepare("SELECT FlavourID FROM ProductFlavours WHERE FlavourName = ?")) {
			$stmt_flav->bind_param('s', $flavour);
			$stmt_flav->execute();
			$stmt_flav->bind_result($flavour_ID);
			$stmt_flav->fetch();
			$stmt_flav->close();
		}

		//Generate 9 digit ordered_item_ID
		$sql_query = mysqli_query($conn,'SELECT MAX(OrderedItemID) as maximum FROM OrderedItem');
		$row = mysqli_fetch_assoc($sql_query);
		$ordered_item_ID = $row["maximum"] + 1;
		$new_ordered_item_ID = sprintf('%09d',$ordered_item_ID);
		mysqli_free_result($sql_query);

		//Insert information about ordered items into the database
		$sql = "INSERT INTO OrderedItem (OrderedItemID, OrderID, SizeName, FlavourID, DairyFree, ProductQuantity)
		VALUES ('$new_ordered_item_ID', '$order_ID', '$size', '$flavour_ID', '$dairy_free', '$quantity')";

		if (mysqli_query($conn, $sql)) {
//			echo "New record created successfully";
		} else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
	}
}

// Adds order information to the database and returns the orderID
function createNewOrder($customer_ID, $Delivery_ID, $price, $current_time, $current_date){

	global $conn;

	//Generate 9 digit order_ID
	$sql_query = mysqli_query($conn,'SELECT MAX(OrderID) as maximum FROM Orders');
	$row = mysqli_fetch_assoc($sql_query);
	$order_ID = $row["maximum"] + 1;
	$new_order_ID = sprintf('%09d',$order_ID);

	if($Delivery_ID != 'NULL') {
		$sql = "INSERT INTO Orders (OrderID, CustomerID, DeliveryID, TotalPrice, Time, Date, TransactionAccepted)
		VALUES ('$new_order_ID', '$customer_ID', '$Delivery_ID', '$price', '$current_time', '$current_date', '1')";
	} else {
		$sql = "INSERT INTO Orders (OrderID, CustomerID, DeliveryID, TotalPrice, Time, Date, TransactionAccepted)
		VALUES ('$new_order_ID', '$customer_ID', NULL, '$price', '$current_time', '$current_date', '1')";
	}

	if (mysqli_query($conn, $sql)) {
//		echo "New record created successfully";
	} else {
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}

	return $new_order_ID;
}

// Adds delivery information to the database and returns the deliveryID
function createNewDelivery(){

	global $conn;
	global $postcode;
	global $house_number;
	global $street_name;
	$driver_ID = assignDriver();

	$sql_query = mysqli_query($conn,'SELECT MAX(DeliveryID) as maximum FROM Delivery');
	$row = mysqli_fetch_assoc($sql_query);
	$Delivery_ID = $row["maximum"] + 1;
	$new_delivery_ID = sprintf('%09d',$Delivery_ID);

	$sql = "Insert INTO Delivery (DeliveryID, DriverID, HouseNumber, Street, Postcode, DeliveryCompleted) 
		VALUES ('$new_delivery_ID', '$driver_ID', '$house_number', '$street_name', '$postcode', 0)";

	if (mysqli_query($conn, $sql)) {
//		echo "New record created successfully";
	} else {
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}

	return $new_delivery_ID;
}

// Decides which driver should deliver the current delivery based on who delivered the previous one
// Currently cycles through the drivers one-by-one
function assignDriver(){

	global $conn;

	$sql_query = mysqli_query($conn,'SELECT MAX(DeliveryID) as maximum FROM Delivery');
	$row = mysqli_fetch_assoc($sql_query);

	if($row["maximum"]==0) {
		$last_driver = '0003';
	} else {
		$delivery_ID = $row["maximum"];

		$last_driver = "";
		$stmt = $conn->stmt_init();
		if($stmt = $conn->prepare("SELECT DriverID FROM Delivery WHERE DeliveryID = ?")) {
			$stmt->bind_param('s', $delivery_ID);
			$stmt->execute();
			$stmt->bind_result($last_driver);
			$stmt->fetch();
			$stmt->close();
		}
	}

	if($last_driver == ('0001')){
		$new_driver = '0002';
	} elseif ($last_driver == '0002') {
		$new_driver = '0003';
	} elseif ($last_driver == '0003') {
		$new_driver = '0001';
	}

	return $new_driver;
}

?>
