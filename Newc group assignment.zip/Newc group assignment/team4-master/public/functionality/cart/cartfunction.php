<?php
// Authors: Danyang & DuHao
// add to shopping cart
function addCart($pname, $psize, $dairyfree)
{
    $pid=0;
    // The first click creates an array
    if (empty(unserialize($_COOKIE['cart']))) {
        $arr = array( array($pname, 1, $psize, $dairyfree));
        setcookie('cart', serialize($arr),time()+3600*24*30,'/');
    }
    else {
        $arr = unserialize($_COOKIE['cart']);
        // If the cart doesn't have this items, add an array for this items.
        foreach($arr as $key=>$value ){
          if ($value[0] == $pname && $value[2] == $psize && $value[3]==$dairyfree) {
                    $arr[$key][1]++;
                    setcookie('cart', serialize($arr),time()+3600*24*30,'/');
                    return;
                }
          }
        $pid = $key + 1;
        $arr[$pid] = array($pname, 1, $psize, $dairyfree);
        setcookie('cart', serialize($arr),time()+3600*24*30,'/');
        }
}

// Delete an item
function delQuantity($shop_car, $del)
{
    //unset($shop_car[$del]);
    if ($shop_car[$del][1] > 1){
        $shop_car[$del][1] = $shop_car[$del][1]-1;
        setcookie('cart', serialize($shop_car),time()+3600*24*30,'/');
    }
    else
    {
      unset($shop_car[$del]);
      setcookie('cart', serialize($shop_car),time()+3600*24*30,'/');
    }

}
//Add the same product
function addQuantity($shop_car,$add)
{
        $shop_car[$add][1] = $shop_car[$add][1]+1;
        print_r ($shop_car);
        setcookie('cart', serialize($shop_car),time()+3600*24*30,'/');

}

//Empty shopping cart
function delAll()
{
    if (isset($_GET['clean'])) {
        if ($_GET['clean'] == 'all') {
            setcookie('cart', '', time()+3600*24*30,'/');
            echo '<script>alert("Basket emptied");window.location.href="../pages/menu.php";</script>';
        }
    }
}


// Calculate total price
function totalPrice($shop_car)
{
    require '../../config/connect.php';
    $price = 0;
    if(count($shop_car) != 0){
      foreach ( $shop_car as $kk) {
              $sql = 'select price from ProductSizesPrices where SizeName="' . $kk[2] . '"';
              $sql1 = 'select Surcharge from ProductFlavours where FlavourName="'.$kk[0].'"';
              $select = $conn->query($sql);
              $select1 = $conn->query($sql1);
              $result = $select->fetch_object();
              $result1 = $select1->fetch_object();
              $price += $kk[1] * ($result->price + $result1->Surcharge);
          }
          $conn->close();
          return number_format($price,2);
    }
         return number_format($price,2);

}

function unitPrice($pname,$psize){
      require '../../config/connect.php';
      $sql = 'select price from ProductSizesPrices where SizeName="' . $psize . '"';
      $sql1 = 'select Surcharge from ProductFlavours where FlavourName="'.$pname.'"';
      $select = $conn->query($sql);
      $select1 = $conn->query($sql1);
      $result = $select->fetch_object();
      $result1 = $select1->fetch_object();
      $unitprice = $result->price + $result1->Surcharge;
      $conn->close();
      return number_format($unitprice,2);
}

?>


