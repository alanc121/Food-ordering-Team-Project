<?php
// Authors: Danyang & DuHao
require_once 'cartfunction.php';

$pname = $_GET['flavour'];
$psize = $_POST['size'];
$dairyfree = null;
$dairyfree  = $_POST['dairyfreeoption'];

//The query returns empty, to avoid adding empty items to the cart.
if (empty($pname) ) {
    echo '<script>alert("Product not found");window.location.href = "../../pages/menu.php"</script>';
    exit;
}
else if (empty($psize)) {
    echo '<script>alert("Please choose the size");window.location.href = "../../pages/product.php?flavour=' . $pname . '"</script>';
    exit;
}
else{
     addCart($pname, $psize, $dairyfree);
     echo '<script>window.location.href = "../../pages/menu.php"</script>';
}

?>

