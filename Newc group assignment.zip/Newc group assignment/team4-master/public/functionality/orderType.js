// Saving the order type selected as a cookie (Manon)

function setOrderTypeCookie(orderType) {
    var expDate = new Date();
    expDate.setTime(expDate.getTime() + 24 * 60 * 60 * 1000); // Save order method for 24h 
    document.cookie = "orderType = " + orderType + "; expires=" + expDate.toUTCString() + "/path=/";
}

function getOrderTypeCookie() {
    var decodedCookie = decodeURIComponent(document.cookie);
    var cookieArray = decodedCookie.split(';');
    for (var i = 0; i < cookieArray.length; i++) {
        var cookiePair = cookieArray[i].split("=");
        if ("orderType" == cookiePair[0].trim()) {
            return cookiePair[1];
        }
    }
    return "none";
}
