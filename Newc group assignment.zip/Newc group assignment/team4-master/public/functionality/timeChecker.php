<?php

// Time checking functionality (added by Manon)

date_default_timezone_set("Europe/London");

// Shop opening times
$opening_time_str = "11:00";
$closing_time_str = "18:00";

$opening_time = DateTime::createFromFormat("H:i", $opening_time_str);
$closing_time = DateTime::createFromFormat("H:i", $closing_time_str);

// Current time
$current_time = new DateTime();

// Check whether shop is currently open
if ($current_time >= $opening_time && $current_time <= $closing_time) {
    $shop_is_open = TRUE;
} else {
    $shop_is_open = FALSE;
}
//TODO: UNCOMMENT AFTER TESTING

