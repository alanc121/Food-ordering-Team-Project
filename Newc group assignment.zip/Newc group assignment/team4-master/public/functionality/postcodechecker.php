<?php
/* Prototype by Zhongyuan & Mingwei */
/* Implement & Future Debug by Manon & Alan */

//$addressErr = 
$postcodeErr = "";
//$address = 
$postcode = "";
$postcodeExist = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

  if (empty($_POST["postcode"])) {
    $postcodeErr = "Postcode is necessary";
  } else {
    $postcode = format_postcode(test_input($_POST["postcode"]));
    if (test_postcode($postcode) === TRUE) {
      $postcodeExist = "Congratulations, your address is within our delivery range.";
      $_SESSION["ordermethod"] = "delivery";
    } else {
      $postcodeExist = "Sorry, your address isn't within the five-mile delivery range, but you can still choose to collect the ice cream. (Or you may check if your postcode is correct.)";
      $_SESSION["ordermethod"] = "collection";
    }
  }
} else {
  $_SESSION["ordermethod"] = "collection";
  // If postcode is not checked, assume collection (Manon)
}

function test_input($data)
{
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  // Additional string sanitizing
  return filter_var($data, FILTER_SANITIZE_STRING);
}




function format_postcode($postcode)
{
  // written by Manon
  // Formats the postcode so that it matches the format of the postcode list
  $postcode = strtoupper($postcode); // Ensure all-caps
  $postcode = preg_replace('/\s/', "", $postcode); // Remove existing spaces
  $postcode = substr_replace($postcode, " ", -3, 0); // Postcodes should always have a space before the last 3 characters
  return $postcode;
}


function test_postcode($postcode)
{
  $postcodeInList = FALSE;
  $a = "";
  $fp = fopen("../functionality/listOfPostcodes.txt", 'r') or die("Unable to open file!");
  if (file_exists("../functionality/listOfPostcodes.txt")) {
    while (!feof($fp)) {
      $c = fgetc($fp);
      if ($c != "	") {
        $a = $a . $c;
        if ($a === $postcode) {
          $postcodeInList = TRUE;
        }
      } else {
        $a = "";
      }
    }
  }
  fclose($fp);
  return $postcodeInList;
}

?>
