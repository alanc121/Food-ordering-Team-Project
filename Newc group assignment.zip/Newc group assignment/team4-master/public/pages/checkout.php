<?php
include '../../config/connect.php'; // Connect to database
require_once '../functionality/cart/cartfunction.php';
$this_page = "checkout";
$error_message = "";
$empty_cart = "";
include '../functionality/postcodechecker.php';
session_start();
$shop_car = unserialize($_COOKIE['cart']);


// Redirect user to page they were on before
$redirect_url = (isset($_SESSION["redirect_url"]) ? $_SESSION["redirect_url"] : "home.php");

//Use checkpostcode if order details are changed and submitted to allow users to order to different addresses
//despite their account  address - Josh and Dylan
function checkPostcode()
{
    $edited_post = format_postcode($_POST['postcode']);
    if (test_postcode($edited_post)) {
        return true;
    }
}

//Post the data to same page- clean the data that may have been inputted and store it in a session
//Check if postcode is in range and set new delivery session variables if it is
//If customer selected delivery and time is after 5:45 but before the shop shuts then it will throw an error
if (isset($_GET['posty'])) {
    if (!empty($shop_car)) {
        $method = "" . $_POST['checkout-order-type-select'] . "";
        $_SESSION['checkout-order-type-select'] = "" . $method . "";
        if ($_POST['checkout-order-type-select'] === 'delivery') {
            if (checkPostcode()) {
                $_SESSION['housenumber'] = ucwords(strtolower(test_input($_POST['housenumber'])));
                $_SESSION['streetname'] = ucwords(strtolower(test_input("" . $_POST['streetname'] . "")));
                $_SESSION['postcode'] = preg_replace('/\s/', '', (strtoupper(format_postcode(test_input("" . $_POST['postcode'] . "")))));

                header("Location: ../functionality/horsePayFunction.php");
            } else {
                $error_message = "Sorry, we do not deliver there. Please try another address or select collection.";
            }
        } else {
            if ((date("Hi") > "1745") && (date("Hi") < "1800")) {
                $error_message = "Sorry, the last time you may place a collection order is 5:45PM. Please order for delivery
                or try again when we are next open for collections.";
            } else {
                header("Location: ../functionality/horsePayFunction.php");
            }
        }
    } else {
        $empty_cart = "There is nothing in your basket. Please add items before you pay.";
    }
}

include '../common/header.php';
// If shop is closed disable the checkout button (added by Manon)
$disabled_attribute = "";
$horsepay_link = "document.getElementById('form').submit();";
if (!$shop_is_open) {
    $disabled_attribute = "disabled";
    $horsepay_link = "";
}

?>


    <div class='col-md-12'>
        <a class="back__btn" href="<?= $redirect_url ?>">＜</a>
    </div>

    <form action="" method="POST" enctype="multipart/form-data">
        <!-- form Begin -->

        <div class="col-md-6">
            <!-- col-md-6 Begin -->

            <h1 class="checkout__title" style="font-family: Vollkorn, serif">Basket</h1>

            <?php
            //author: Danyang
            $totalquality = 0;
            if (empty($shop_car)) {
                echo '<h2 id="checkout__total" style= "font-family: Vollkorn, serif" >Shopping cart is empty</h2>';
            } else {
                $key = array_keys($shop_car);
                for ($i = 0; $i < count($shop_car); $i++) {
                    $cart_id = $key[$i];
                    $checkout_flavor = $shop_car[$key[$i]][0];
                    $checkout_size = $shop_car[$key[$i]][2];
                    $checkout_unitPrice = unitPrice($shop_car[$key[$i]][0], $shop_car[$key[$i]][2]);
                    $checkout_quantity = $shop_car[$key[$i]][1];
                    $checkout_dairyfree = $shop_car[$key[$i]][3];
                    $checkout_totalquality = $totalquality + $shop_car[$key[$i]][1];
                    ?>

                    <div class="showcase" id="checkout_showcase">
                        <!-- showcase Begin -->

                        <table>
                            <!-- table Begin -->

                            <tr>
                                <!-- tr Begin -->

                                <td id=td-1>

                                    <img class="img-responsive" src="../img/<?php echo $checkout_flavor; ?>.jpg" alt="img/vanilla2.jpg" title="<?php echo $checkout_flavor; ?>" height="80" width="80">

                                </td>

                                <td id=td-2>

                                    <ul>
                                        <li><?php echo "<a href='../pages/product.php?flavour=$checkout_flavor'>"; ?>
                                            <strong><?php echo "$checkout_dairyfree" . ' ' . "$checkout_flavor"; ?></strong></a>
                                        </li>
                                        <li class="text-muted"><?php echo $checkout_size; ?></li>
                                        <li class="text-muted"><?php echo $checkout_unitPrice; ?></li>
                                    </ul>

                                </td>

                                <td id=td-3>

                                    <ul>
                                        <li><?php echo '<a href="../pages/checkout.php?add=' . $key[$i] . '">+</a> '; ?></li>
                                        <li><?php echo $checkout_quantity; ?></li>
                                        <li><?php echo '<a href="../pages/checkout.php?del=' . $key[$i] . '">-</a> ' ?></li>
                                    </ul>

                                </td>

                            </tr><!-- tr Finish -->

                        </table><!-- table Finish -->

                    </div><!-- showcase Finish -->

                <?php }
                $checkout_totalPrice = totalPrice($shop_car);
                echo "<br/><h2 id='basket__total'style= 'font-family: Vollkorn, serif '>Total: £$basket_totalPrice </h2>";
                $del = $_GET['del'];
                $add = $_GET['add'];
            }
            ?>

        </div><!-- col-md-6 Finish -->

        <div class="col-md-6 checkout">
            <!-- col-md-6 Begin -->

            <h2 class="checkout__sub-title" id="checkout__sub-title" style="font-family: Vollkorn, serif">Delivery Location</h2><br>

    </form>


    <!-- Retrieve customer details about whoever is logged in, use it to produce default values and an editable field
     for delivery address Dylan -->
<?php
$customer_id = $_SESSION['customerID'];
$sql_customer_results = mysqli_query($conn, "SELECT * from Customer WHERE CustomerID ='" . $customer_id . "'");
$customer_assoc = mysqli_fetch_assoc($sql_customer_results);

$customer_house = $customer_assoc["HouseNumber"];
$customer_street = $customer_assoc["Street"];
$customer_postcode = $customer_assoc["Postcode"];

if (isset($_SESSION['housenumber'])) {
    $customer_house = "" . $_SESSION['housenumber'] . "";
}
if (isset($_SESSION['streetname'])) {
    $customer_street = "" . $_SESSION['streetname'] . "";
}

if (isset($_SESSION['postcode'])) {
    $customer_postcode = "" . $_SESSION['postcode'] . "";
}


mysqli_free_result($sql_customer_results);
?>

    <!-- Create input fields where users can change their delivery address with the default value being their saved account
     delivery address -->
    <div class="checkout_delivery">
    <form method="POST" name="form" id="form" action="checkout.php?posty=true" onsubmit="return validateForm()">

        <select name="checkout-order-type-select" id="checkout-order-type-select" aria-label="Order method">
            <option id='delivery' value='delivery'>Delivery</option>
            <option id='collection' value='collection'>Collection</option>
        </select>
        <br>
        <br>

        <p class="error_mes"> <?php echo $empty_cart ?> </p>
        <div class="delivery_options" id="delivery_options">
            <p class="error_mes"> <?php echo $error_message ?></p>
            <label>House Name/Number:</label>
            <input type="text" name="housenumber" id="housenumber" value="<?= $customer_house ?>">
            <br>

            <label>Street:</label>
            <input type="text" name="streetname" value="<?= $customer_street ?>">

            <br>
            <label>Postcode:</label>
            <input type="text" name="postcode" value="<?= $customer_postcode ?>">
            <br><br>
        </div>

        <?php
        echo '<a onclick="' . $horsepay_link . '" type="submit" class="btn btn-primary" id="checkout__btn"' . $disabled_attribute . '>
        Checkout with HorsePay</a>';
        ?>
    </form>

    <!-- Assigns the stored customer details to the post variable if the user does not change the information -->
    <script>
        function validateForm() {
            var option = document.getElementById('checkout-order-type-select').value;
            if (option === "delivery") {
                if (document.forms["form"]["housenumber"].value === "") {
                    document.forms["form"]["housenumber"].value = "<?php echo $customer_house ?>"
                }
                if (document.forms["form"]["streetname"].value === "") {
                    document.forms["form"]["streetname"].value = "<?php echo $customer_street ?>"
                }
                if (document.forms["form"]["postcode"].value === "") {
                    document.forms["form"]["postcode"].value = "<?php echo $customer_postcode ?>"
                }
                return true;
            }
        }
    </script>

    <!-- AJAX for postcode checker added by Manon from Kimberly's jQuery code -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <script>
        //Select the order type if it has already been chosen
        orderType = getOrderTypeCookie();
        if (orderType === "delivery") {
            $("#checkout-order-type-select").val("delivery");
            $("#delivery_options").show();
            $("#checkout__sub-title").text("Delivery Location");
        }
        if (orderType === "collection") {
            $("#checkout-order-type-select").val("collection");
            $("#delivery_options").hide();
            $("#checkout__sub-title").text("Collection");

        }

        $(function() {
            $("#checkout-order-type-select").change(function() {
                var option = $("#checkout-order-type-select").val();
                if (option === "delivery") {
                    setOrderTypeCookie("delivery");
                    $("#delivery_options").show();
                    $("#checkout__sub-title").text("Delivery Location");
                }
                if (option === "collection") {
                    setOrderTypeCookie("collection");
                    $("#delivery_options").hide();
                    $("#checkout__sub-title").text("Collection");
                }
            })
        })
    </script>

<?php
include '../common/footer.php';
?>