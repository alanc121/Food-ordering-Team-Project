<?php

/**
 * Author: Kimberly Dijkmans
 * The dynamic menu page will display the ice cream flavours available retrieved from the database.
 * If no products are found this will be indicated with a message.
 * The user will be able to filter on dairy free flavours.
 */

$this_page = "menu";
include '../common/header.php';
include '../../config/connect.php';

/* To indicate how many of a specific flavour are currently in the basket */
session_start();
$shop_car = unserialize($_COOKIE['cart']);

?>

<!-- Dairy free filter option -->
<div class="menu__dairyfree col-md-12">
    <input type='checkbox' id='dairyfreeoption' name='dairyfreeoption' value='DairyFree'>
    <label for='dairyfreeoption'></label></td>
    <p>Dairy Free</p>
</div>

<?php

// Get flavour information from database
$sqlFlavour = "SELECT FlavourName, Surcharge, DairyFree from ProductFlavours";
$resultFlavours = $conn->query($sqlFlavour);
// Get sizes and prices available from database
$sqlPrice = "SELECT Price from ProductSizesPrices";
$resultPrices = $conn->query($sqlPrice);

// If the result of the sql queries are not 0 then print the HTML and show the product
if ($resultFlavours->num_rows > 0 && $resultPrices->num_rows > 0) {

    $priceFrom = "0";
    while ($row = $resultPrices->fetch_assoc()) {
        if (!$priceFrom || ($row["Price"] < $priceFrom)) {
            $priceFrom = $row["Price"]; // assign the lowest price to $priceFrom

        }
    }

    echo "<div class='menu row'>";

    while ($row = $resultFlavours->fetch_assoc()) {

        echo "<div class='menu-item column' data-dairyfree=" . $row["DairyFree"] . ">
            <a class='menu-item__link' href='product.php?flavour=" . $row["FlavourName"] . "'>
              <img class='menu-item__img' src='../img/" . $row["FlavourName"] . ".jpg' alt='" . $row["FlavourName"] . " ice cream flavour' title='" . $row["FlavourName"] . "' height='300' width='300' />
              <h2 class='menu-item__title'>" . $row["FlavourName"] . "</h2>";

        $price = (float)$priceFrom + (float)$row["Surcharge"];
        $formattedPrice = number_format($price, 2, '.', '');
        echo "<p class='menu-item__price'>from £ " . $formattedPrice . "</p>";

        // Label on flavour to indicate whether it has a dairy free option
        if ($row["DairyFree"] == 1) {
            echo "<p class='menu-item__dairyfreelabel'>dairy free option</p>";
        }

        // Count how many of a specific flavour are currently in the basket
        $counter = 0;
        $key = array_keys($shop_car);
        for ($i = 0; $i < count($shop_car); $i++) {
            if ($shop_car[$key[$i]][0] == $row["FlavourName"]) {
                $counter = $counter + $shop_car[$key[$i]][1];
            }
        }

        // Label on flavour to indicate how many of a that flavour are currently in the basket
        if ($counter != 0) {
            echo "<p class='menu-item__amountbasketlabel'>$counter</p>";
        }

        echo "</a></div>";
    }

    echo "</div>";
} else { // If there is no result from an sql query then print an error message
    echo "no products found";
}

$conn->close(); //close the database connection

include '../common/footer.php';
?>

<!-- jQuery to achieve real-time filtering of dairy-free products -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script>
    $(function() {
        $("#dairyfreeoption").click(function() {
            if ($(this).prop("checked") == true) {
                //console.log("Checkbox is checked.");
                $(".menu-item[data-dairyfree='0']").css("display", "none");
            } else if ($(this).prop("checked") == false) {
                //console.log("Checkbox is unchecked.");
                $(".menu-item[data-dairyfree='0']").css("display", "inline-block");
            }

        });
    })
</script>