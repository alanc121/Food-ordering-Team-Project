<?php
// Written by Manon
session_start();

unset($_SESSION['customer_login']);
unset($_SESSION['customerID']);

// Redirect user to page they were on before logging in
$redirect_url = (isset($_SESSION["redirect_url"]) ? $_SESSION["redirect_url"] : "/");

header("Location: " . $redirect_url);

?>
