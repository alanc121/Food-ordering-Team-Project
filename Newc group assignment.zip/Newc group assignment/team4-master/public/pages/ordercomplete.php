<?php
//
// Written by Alan and Dylan
//


//If customerID is empty or OrderID is empty then redirect to home.php
session_start();
$customer_id = $_SESSION["customerID"];
$new_order_id = $_SESSION['newOrderID'];
$house = $_SESSION["housenumber"];
$street = $_SESSION["streetname"];
$postcode = $_SESSION["postcode"];
$estimated_time="";

//Cannot access page if not coming from
if (empty($new_order_id) || empty($customer_id)) {
    header('Location:home.php');
    exit();
}

$this_page = "ordercomplete";
include '../../config/connect.php';
include '../common/header.php';

include_once '../functionality/cart/cartfunction.php';



//Get order details from database
$sql_order = mysqli_query($conn, "SELECT * from Orders WHERE OrderID = '$new_order_id'");
$sql_result_order = mysqli_fetch_assoc($sql_order);
$order_time = $sql_result_order["Time"];
$order_method = $_SESSION['checkout-order-type-select'];

mysqli_free_result($sql_order);


//Collect customer information from database for use on page
$sql_customer = mysqli_query($conn, "SELECT * from Customer WHERE CustomerID = '$customer_id'");
$sql_result_customer = mysqli_fetch_assoc($sql_customer);
$first_name = $sql_result_customer["Forename"];
$surname = $sql_result_customer["Surname"];
$email = $sql_result_customer["Email"];

mysqli_free_result($sql_customer);

$shop_car = unserialize($_COOKIE['cart']);

?>


<html>
<body>
<!-- Display message based on delivery or collection and set order time-->
<div class="topText">
    <h2 class="display-3">Thank you for your order <?php echo $first_name ?></h2>
    <?php if ($order_method === "delivery") {
        $estimated_time= date('H:i', strtotime('+20 mins', strtotime($order_time)));
        echo "<h3> Your order number is <strong>$new_order_id</strong> and will be delivered to you at approximately <strong>$estimated_time</strong> </h3>";
    } else {
        $estimated_time = date('H:i', strtotime('+10 mins', strtotime($order_time)));
        echo "<h3> Your order number is <strong>$new_order_id</strong> and will be ready to collect from <strong>$estimated_time</strong> </h3>";
    }

    ?>
</div>

<!-- Show customers address -->
<?php if ($order_method === "delivery") {
    echo
    "<div class=\"delivery_details\">
    <h4> Your order is out for delivery to: </h4>
    <p>  $first_name $surname,  <br>
        $house $street, <br>
        $postcode </p>
    </div>";
    }
?>

<!-- Print basket as table -->
<div class="order-details">
    <h4> Order Summary: </h4>
    <div class="basketShowcase" id="basketShowcase">
        <table>
            <th> Product</th>
            <th> Size</th>
            <th> Dairy Free</th>
            <th> Quantity</th>
            <th> Subtotal</th>

            <?php
            $key = array_keys($shop_car);
            for ($i = 0; $i < count($shop_car); $i++) {
                $basket_flavor = $shop_car[$key[$i]][0];
                $basket_size = $shop_car[$key[$i]][2];
                $basket_unitPrice = number_format(unitPrice($shop_car[$key[$i]][0],$shop_car[$key[$i]][2]),2);
                $basket_quantity = $shop_car[$key[$i]][1];
                $basket_dairyfree = $shop_car[$key[$i]][3];
                $basket_subtotal = number_format(($basket_quantity * $basket_unitPrice), 2);

                if ($basket_dairyfree === 1) {
                    $basket_dairyfree = "Yes";
                } else {
                    $basket_dairyfree = "No";
                }
                ?>

                <tr>
                    <td><?php echo $basket_flavor; ?> </td>
                    <td> <?php echo $basket_size; ?> </td>
                    <td> <?php echo $basket_dairyfree ?></td>
                    <td> <?php echo $basket_quantity ?></td>
                    <td> £<?php echo $basket_subtotal; ?> </td>
                </tr>
            <?php } ?>
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td> <?php
                    // Total price
                    $basket_totalPrice = totalPrice($shop_car);
                    echo "<p id='totalPrice'>Total: £$basket_totalPrice </p>";
                    ?>
                </td>
            </tr>
        </table>
    </div>
</div>


<p class="lead"><strong>Please check your email</strong> for further information on your order.</p>
<p class="lead">
    <a href="../pages/home.php" class="btn btn-primary btn-sm" id="basket__btn" role="button">Go back to Homepage</a>


    <!-- Change email based on delivery or collection then send email using customer details -->

    <?php
    if ($order_method === "delivery") {
        $delivery_time = "Your ice cream will be delivered to you at approximately: ".$estimated_time." \n
        It has been sent to: \n
        ".$first_name." ".$surname.", 
        ".$house.", ".$street.",
        ".$postcode." ";
    }
    else{
        $delivery_time = "Your ice cream will be ready for collection at: ".$estimated_time."";
    }


    //Send the email

    $to = "$email";
    $subject = "Cavallo - Order Number: " . $_SESSION['newOrderID'] . "";
    $txt = "Confirmation Order Number: " . $_SESSION['newOrderID'] . "\n\n\n   Thank you for your order " . $first_name . ",
    You have been charged: £".$basket_totalPrice.",\n
    ".$delivery_time." \n
    Your custom is very much appreciated and we hope you enjoy your ice cream! \n\n
    Kind regards, 
    The Cavallo Team";
    $headers = "From: cavallo@mail.com";


    mail($to, $subject, $txt, $headers);


    /*Stop user revisiting order page once they have clicked away*/
    unset($_SESSION['newOrderID']);
    ?>

</p>



<p class="lead"> Having trouble? <a href="">Contact us</a> </p>


</body>
<!-- Clears cart after page has been seen -->
<script type="text/javascript">
    document.cookie = "cart=; expires=Thu, 01 Jan 1970 00:00:01 GMT; path=/";
</script>
</html>





