<?php
include '../../config/connect.php';

$this_page = "home";

include '../common/header.php';
include '../functionality/postcodechecker.php';


// Postcode autofill functionality (added by Manon)
$postcode = "";

if ($_SESSION["customer_login"] === TRUE) {
    // If a customer is already logged in, auto-fill their postcode into the postcode checking form
    $postcode = findCustomerPostcode();
}

function findCustomerPostcode()
{
    // Finds the customer's postcode from customer ID
    global $conn;
    $customerID = $_SESSION["customerID"];
    $stmt_pc = $conn->stmt_init();
    if ($stmt_pc = $conn->prepare("SELECT Postcode FROM Customer WHERE CustomerID = ?")) {
        $stmt_pc->bind_param('s', $customerID);
        $stmt_pc->execute();
        $stmt_pc->bind_result($customer_postcode);
        $stmt_pc->fetch();
        $stmt_pc->close();
        return $customer_postcode;
    }
}

?>

<div class="intro">
    <p>Welcome to Cavallo, an authentic Italian ice cream shop located at Avenue Crescent, Seaton Delaval.</p>

    <p>We are open 11:00-18:00 7 days a week but be aware that we stop taking orders 15 minutes before closing.</p>

    <p>Have a scroll of our delicious flavours and place an order for collection or delivery (up to 5 miles away).</p>

    <p>We also have dairy-free options available so everyone can enjoy a scoop!</p>
</div>

<!-- Form uses postcodechecker.php functionality to check whether a postcode is within the 5-mile delivery radius (added by Manon) -->

<div class="postcode-checker-group">
    <div class="order-type">
        <form method="POST">
            <div>
                <select id="order-type-select" name="ordertype" aria-label="Select order type">
                    <option value="delivery">Delivery</option>
                    <option value="collection">Collection</option>
                </select>
            </div>
        </form>
    </div>
    <div class="postcode-checker" id="postcode-checker-div">
        <form method="POST">
            <input type="text" id="postcode-entry" name="postcode" placeholder="Enter your postcode..." value="<?= $postcode ?>" aria-label="Check postcode for delivery">
            <input type="submit" class="btn-primary" id="postcode-submit" value="Check my postcode" aria-label="check my postcode">
        </form>
        <div class="postcode-feedback">
            <br><br>
            <p id="error-message"><?= $postcodeErr ?></p>
            <p id="postcode-message"><?= $postcodeExist ?></p>
            <br><br>
        </div>
    </div>

</div>


<button id="view-menu" class="btn-primary" type="button" onclick="window.location.href='menu.php';" aria-label="go to menu page">View menu</button>

<?php
$conn->close(); // Close the database connection
include '../common/footer.php';
?>


<!-- AJAX for postcode checker added by Manon adapted from Kimberly's jQuery code -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script>
    $(function() {
        $("#order-type-select").change(function() {
            var option = $("#order-type-select").val();
            if (option === "delivery") {
                $("#postcode-checker-div").show();
                setOrderTypeCookie("delivery");
            }
            if (option === "collection") {
                $("#postcode-checker-div").hide();
                setOrderTypeCookie("collection");
            }
        })
    })
    // Select the order type if it has already been chosen
    orderType = getOrderTypeCookie();
    if(orderType === "delivery") {
        $("#order-type-select").val("delivery");
        $("#postcode-checker-div").show();
    }
    if(orderType === "collection") {
        $("#order-type-select").val("collection");
        $("#postcode-checker-div").hide();
    }
</script>

