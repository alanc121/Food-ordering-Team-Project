<?php
$this_page = "customerregistration";
include '../../config/connect.php';
include '../common/header.php';

//Written by Manon and Dylan


// Redirect user to page they were on before
$redirect_url = (isset($_SESSION["redirect_url"]) ? $_SESSION["redirect_url"] : "home.php");


$feedback_message = "";
$general_message = "";

// Valid variables will be stored so that they don't need to be entered twice
$customer_f_name = "";
$customer_s_name = "";
$house_num = "";
$street = "";
$postcode = "";
$customer_email = "";
$phone_number = "";

//Popup and redirect to login page when account created
function confirm_alert(){
    echo "<script>
            alert('Your account has been successfully created. Returning to login screen.');
                window.location.href='customerlogin.php';
           </script>";
}

//Functions to clean and filter user input
function test_input($data)
{
    $data = trim($data);
    $data = htmlspecialchars($data);
    return $data;
}

function filterString($data)
{   
    global $feedback_message;
    if (filter_var($data, FILTER_SANITIZE_STRING)) {
        $data = ucwords(strtolower($data));
        return $data;
    } else {
        $feedback_message .= "Error: could not sanitize data.\n";
        unset($data);
    }
}

function filterEmail($data)
{
    global $feedback_message;
    if (filter_var($data, FILTER_SANITIZE_EMAIL)) {
        return strtolower($data);
    } else {
        $feedback_message .= "Error: could not sanitize email.\n";
        unset($data);
    }

}

function checkEmailIsUnique($email) {
    global $conn;
    $stmt_email = $conn->stmt_init();
    if($stmt_email = $conn->prepare("SELECT CustomerID FROM Customer WHERE Email = ?")) {
        $stmt_email->bind_param('s', $email);
        $stmt_email->execute();
        $stmt_email->bind_result($customerID);
        $stmt_email->fetch();
        $stmt_email->close();
        if(!isset($customerID)) {
            return TRUE;
        } else {
            return FALSE;
        }
    } else {
        return FALSE;
    }
}

function registerCustomer() {
    global $conn;
    //Generate 5 digit customer number
    $sql_query = mysqli_query($conn,'SELECT MAX(CustomerID) as maximum FROM Customer');
    $row = mysqli_fetch_assoc($sql_query);
    $customer_number = $row["maximum"] + 1;
    $new_customer_id = sprintf('%05d',$customer_number);

    global $customer_f_name, $customer_s_name, $house_num, $street, $postcode, $phone_number, $customer_email, $customer_password;
    $stmt = "INSERT INTO Customer (CustomerID, Forename, Surname, HouseNumber, Street, Postcode, PhoneNumber, Email, Password) VALUES ('$new_customer_id', '$customer_f_name', '$customer_s_name', '$house_num', '$street', '$postcode', '$phone_number', '$customer_email', '$customer_password')";
    if($result = mysqli_query($conn, $stmt)) {
        mysqli_free_result($result);
        return TRUE;
    } else {
        return FALSE;
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Sanitize and store data with consistent format (first letter of each word capitalised)

    $customer_f_name = filterString(test_input($_POST["customer_f_name"]));
    $customer_s_name = filterString(test_input($_POST["customer_s_name"]));

    $house_num = filterString(test_input($_POST["house_num"]));
    $street = filterString(test_input($_POST["street"]));
    $postcode = preg_replace('/\s/', '', (strtoupper(filterString(test_input($_POST["postcode"])))));

    $phone_number = filterString(test_input($_POST["phone_number"]));

    $customer_email = strtolower(filterEmail(test_input($_POST["customer_email"])));

    $customer_password = htmlspecialchars($_POST["customer_password"]);
    $confirm_password = htmlspecialchars($_POST["confirm_password"]);

    if (!filter_var($customer_email, FILTER_VALIDATE_EMAIL)) {
        $feedback_message .= "Incorrect email format.\n";
        unset($customer_email);
    }
    
    if (!checkEmailIsUnique($customer_email)) {
        $feedback_message .= "Email already in use.\n";
        unset($customer_email);
    }

    if (!filter_var($phone_number, FILTER_VALIDATE_REGEXP, array("options" => array("regexp" => "/^\d*$/")))) {
        $feedback_message .= "Phone number can only contain digits.\n";
        unset($phone_number);
    }

    
    if (isset($phone_number, $customer_email, $street, $postcode, $confirm_password, $customer_f_name,
        $customer_s_name, $house_num)) {
        
        if ($customer_password === $confirm_password) {
            $success = registerCustomer();
            if(!$success) {
                $feedback_message = "There was an error with your registration. Please try again later.";
            } else {
                confirm_alert();
            }
        }
        else {
            $feedback_message = "Please ensure that your passwords match";
        }
    } else {
        $general_message = "There was an error with your registration. Please ensure all fields are filled in correctly.";
    }


}

?>


<div class='col-md-12'>
    <a class="back__btn" href="<?=$redirect_url?>">＜</a>
</div>

<div class="login">
<h1>Create New Account</h1>
<div class="error">
    <p><?=$feedback_message?></p>
    <p><?=$general_message?></p>
</div>
<form action="" method="POST">
    <label for="text">First Name:</label>
    <input id="customer_f_name" name="customer_f_name" type="text" required minlength="1" maxlength="100" value="<?=$customer_f_name?>">
    <br>
    <label for="text">Surname:</label>
    <input id="customer_s_name" name="customer_s_name" type="text" required minlength="1" maxlength="100" value="<?=$customer_s_name?>">
    <br>

    <label for="text">House Name/Number:</label>
    <input id="house_num" name="house_num" type="text" required minlength="1" maxlength="100" value="<?=$house_num?>">
    <br><label for="text">Street:</label>
    <input id="street" name="street" type="text" required maxlength="100" minlength="1" value="<?=$street?>">
    <br><label for="text">Postcode:</label>
    <input id="postcode" name="postcode" type="text" required maxlength="10" minlength="6" value="<?=$postcode?>">
    <br>

    <label for="text">Phone Number:</label>
    <input id="phone_number" name="phone_number" type="text" required maxlength="11" minlength="11" value="<?=$phone_number?>">
    <br>

    <label for="text">Email Address:</label>
    <input id="customer_email" name="customer_email" type="email" required minlength="10" maxlength="50" value="<?=$customer_email?>">
    <br>

    <label for="text">Password:</label>
    <input id="customer_password" name="customer_password" type="password" required minlength=5 maxlength=20>
    <br>
    <label for="text">Confirm Password:</label>
    <input id="confirm_password" name="confirm_password" type="password" required minlength=5 maxlength=20>
    <br>
    

    <input type="submit" value="Register">

</form>
</div>
</body>

</html>
<?php
$conn->close(); //close the database connection
include '../common/footer.php';
?>