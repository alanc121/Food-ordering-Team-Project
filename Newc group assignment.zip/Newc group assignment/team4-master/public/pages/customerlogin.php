<?php
ob_start();
// Written by Manon & Dylan
// Edited & debugged by Manon

include '../../config/connect.php'; // Connect to database
$this_page = "customerlogin";
include '../common/header.php';


// Redirect user to page they were on before logging in
$redirect_url = (isset($_SESSION["redirect_url"]) ? $_SESSION["redirect_url"] : "home.php");


// Incorrect login details feedback message
$message = "";
$invalid_message = "Invalid email or password. Please try again.";
$unknown_email_message = "No accounts match this email. Please try a different email or create an account.";
$wrong_password_message = "Wrong password. Please try again.";

function findCustomerID($email)
{
    // Finds the customer ID of a customer in the database using their email address
    global $conn;
    $stmt_id = $conn->stmt_init();
    if ($stmt_id = $conn->prepare("SELECT CustomerID FROM Customer WHERE Email = ?")) {
        $stmt_id->bind_param('s', $email);
        $stmt_id->execute();
        $stmt_id->bind_result($customerID);
        $stmt_id->fetch();
        $stmt_id->close();
        return $customerID;
    } else {
        return $conn->error;
    }
}


if ($_SERVER["REQUEST_METHOD"] === "POST") { // Check if form has been submitted
    $raw_email = strtolower(trim(htmlspecialchars($_POST["email"]))); // Sanitize email form entry
    if (filter_var($raw_email, FILTER_VALIDATE_EMAIL)) { // Check for valid email syntax
        $email = $raw_email;
    } else {
        $message = $invalid_message;
    }

    $raw_password = trim(htmlspecialchars($_POST["password"])); // Password is case-sensitive
    if (filter_var($raw_password, FILTER_SANITIZE_STRING)) {
        $password = $raw_password;
    } else {
        $message = $invalid_message;
    }


    // Prepare SQL statement to get a password corresponding to an email
    $stmt_pw = $conn->stmt_init();
    if ($stmt_pw = $conn->prepare("SELECT Password FROM Customer WHERE Email = ?")) {
        $stmt_pw->bind_param('s', $email);
        $stmt_pw->execute();
        $stmt_pw->bind_result($correct_password); // Store password into $correct_password
        $stmt_pw->fetch();
        $stmt_pw->close();

        if ($correct_password === NULL) { // No password associated with this email: account doesn't exist
            $message = $unknown_email_message;
        } else if ($password === $correct_password) {
            $_SESSION["customer_login"] = TRUE;
            $customerID = findCustomerID($email);
            $_SESSION["customerID"] = $customerID; // Store customer ID of logged in customer as a session variable


            header("Location: " . $redirect_url); // Redirect to previous page
            exit;
        } else { // Account exists but password is incorrect
            $message = $wrong_password_message;
        }
    }
}

?>

<div class='col-md-12'>
    <a class="back__btn" href="<?=$redirect_url?>">＜</a>
</div>

<!-- HTML Edited by Zhongyuan-->
<div class="col-md-2"></div>

<div class="col-md-8">
    <!-- col-md-8 Begin -->

    <div class="login">
        <!-- customerlogin Begin -->

        <center>
            <!-- center Begin -->

            <h1> Log in </h1><br>

        </center><!-- center Finish -->

        <form action="" method="post" enctype="multipart/form-data">
            <!-- form Begin -->

            <div class="form-group">
                <!-- form-group Begin -->

                <table>

                    <tr>

                        <td class="inputname"><label>Email address: </label></td>

                        <td class="inputvalue"><input type="email" class="form-control" name="email" required minlength=10 maxlength=50></td>

                    </tr>

                </table>

            </div><!-- form-group Finish -->

            <div class="form-group">
                <!-- form-group Begin -->

                <table>

                    <tr>

                        <td class="inputname"><label>Password: </label></td>

                        <td class="inputvalue"><input type="password" class="form-control" name="password" required minlength=5 maxlength=20></td>

                    </tr>

                </table>

            </div><!-- form-group Finish -->

            <div class="text-center">
                <!-- text-center Begin -->

                <button type="submit" name="Login-button" class="btn btn-primary" id="login-button">

                    Log in

                </button>
                
        </form><!-- form Finish -->

                <button class="btn btn-primary" id="login-button" onclick="window.location.href='customerregistration.php';">

                    Create account

                </button>

            </div><!-- text-center Finish -->

        

        <div class="feedback">
            <p><?= $message; ?></p>
        </div><br>

        <center class="text-muted">
            <!-- center Begin -->

            <p> If there are any issues logging in please contact the administrator at </p>
            <p> Team04@newcastle.ac.uk </p>

        </center><!-- center Finish -->

    </div><!-- customerlogin Finish -->



</div><!-- col-md-8 Finish -->

<?php
$conn->close(); //close the database connection
include '../common/footer.php';
?>