<?php

/**
 * Authors: Kimberly Dijkmans & Alice Hughes
 * The dynamic product page will display the individual ice cream flavour that is clicked on on the menu page.
 * If no product is found this will be indicated with a message and the user is able to go back to the menu page.
 * The user will be able to select whether it wants dairy free or not and the size of the product
 * and the user will be able to add the selected product to the basket.
 */

$this_page = "product";
include '../common/header.php';
include '../../config/connect.php';
?>

<!-- Button to go back to the menu page -->
<div class='col-md-12'>
    <a class="back__btn" href="menu.php">＜</a>
</div>

<?php
$flavour = $_GET['flavour']; // Retrieve which flavour was clicked on on the menu page

// Get flavour information from database
$sqlFlavour = "SELECT * from ProductFlavours WHERE FlavourName = '$flavour'";
$resultFlavours = $conn->query($sqlFlavour);
// Get sizes and prices available from database
$sqlSizePrice = "SELECT * from ProductSizesPrices";
$resultSizesPrices = $conn->query($sqlSizePrice);

// If the result of the sql queries are not 0 then print the HTML and show the product
if ($resultFlavours->num_rows > 0 && $resultSizesPrices->num_rows > 0) {

    while ($row = $resultFlavours->fetch_assoc()) {
        $flavourName = $row["FlavourName"];
        $surcharge = $row["Surcharge"];
        $dairyFree = $row["DairyFree"];
    }

    // Show flavour information

    echo "<div class='col-md-5'>
                <img class='product__img' src='../img/" . $flavourName . ".jpg' alt='" . $flavourName . "' title='" . $flavourName . "' height='350' width='350' />
            </div>";

    echo "<div class='col-md-4 product'>
            <h1 class='product__title' style= 'font-family: Vollkorn, serif' >" . $flavourName . "</h1>
            
            <form action='../functionality/cart/addcart.php?flavour=" . $flavourName . "' method='POST'>";

    if ($dairyFree == 1) {
        echo "<input class='product__dairyfree' type='checkbox' id='dairyfreeoption' name='dairyfreeoption' value='DairyFree'>";
        echo "<label for='dairyfreeoption'></label></td>";
        echo "<p>dairy free</p>";
    }

    // Show sizes and prices available

    echo "<select id='product__size' class='product__size' name='size'>
        <option value='' selected disabled>-- Select size --</option>";

    $priceData = array(); // create a variable to hold the prices
    while ($row = $resultSizesPrices->fetch_assoc()) {
        $priceData[] = $row; // add the row in to the priceData array
    }

    $price = array_column($priceData, 'Price');
    array_multisort($price, SORT_ASC, $priceData);

    foreach ($priceData as $item) {
        $value = str_replace(' ', '', $item["SizeName"]);
        echo "<option value=" . $value . " data-price=" . $item["Price"] . ">" . $item["SizeName"] . "</option>";
    }

    echo "</select>";

    echo "<h2 id='product__price' class='product__price'>£ -</h2>"; // Is made dynamic using jQuery, correct price will be shown depending on which size is selected

    echo "<input class='product__submit' id='product__submit' type='submit' value='Add to cart'></form></div>";
} else { // If there is no result from an sql query then print an error message
    echo "<h1>product not found</h1>"; // ****** maybe also a button to go back to the menu page? ******
}

// Adding the list of prices on the right hand side of page -- Alice & Kimberly
// Getting it dynamically from the database
// Get sizes and prices available from database
$sqlSizePrice = "SELECT * from ProductSizesPrices";
$resultSizesPrices = $conn->query($sqlSizePrice);
if ($resultSizesPrices->num_rows > 0) {
    echo "<div class='col-md-3 price__list'>
                <h2>Price List:</h2>
                <ul id='Surcharge-prices'>";

    $priceData = array(); // create a variable to hold the prices
    while ($row = $resultSizesPrices->fetch_assoc()) {
        $priceData[] = $row; // add the row in to the priceData array
    }

    $price = array_column($priceData, 'Price');
    array_multisort($price, SORT_ASC, $priceData);

    foreach ($priceData as $item) {
        $price = (float)$item["Price"] + (float)$surcharge;
        $formattedPrice = number_format($price, 2, '.', '');
        echo "<li>" . $item["SizeName"] . ": £ " . $formattedPrice . "</li>";
    }

    echo "</ul></div>";

    echo $resultSizesPrices->fetch_assoc();
}

$conn->close(); //close the database connection

include '../common/footer.php';

?>

<!-- jQuery to achieve real-time changing of price depending on which size is selected -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script>
    $(function() {
        $("#product__size").change(function() {
            var displayprice = $("#product__size option:selected").data("price");
            var surcharge = "<?php echo $surcharge; ?>";
            var totalprice = Number(displayprice) + Number(surcharge);
            $("#product__price").text("£ " + totalprice.toFixed(2));
        })
    })
</script>