<?php
// Written by Manon
session_start();

session_destroy();

header("Location: stafflogin.php");
exit;
