<?php
session_start();
$message="";
//System in which driver logs on and clicks the box to show delivery has been completed and log the time it was completed -Dylan and Josh
include '../config/connect.php';
$this_page = "deliveries";
$i=1;

//Redirect if not logged in - Changed variables from Alice and Manon code
if ($_SESSION["driver_login"] === FALSE || !isset($_SESSION["driver_login"])) {
    header("Location: driverlogin.php");
    exit;
}

//Check if user inputted something into driver search and clean it if so
if(isset($_POST['delivery_search'])){
    $_SESSION['delivery_search']=htmlspecialchars(trim("".$_POST['delivery_search'].""));
}

//If any deliveries are sent via URL then put them in the database and alert the user that the delivery has been recorded
if (isset($_GET['delivery_ids'])){
    $delivery_id = $_GET['delivery_ids'];
    $delivery_time = date('H:i');
    $delivered = '1';
    $sql_insert= mysqli_query($conn, "UPDATE Delivery SET DeliveryTime = '$delivery_time', DeliveryCompleted = 1 WHERE DeliveryID = '$delivery_id'");
?> <script>alert("Delivery has been recorded"); </script>
<?php
}
?>

<link rel="stylesheet" type="text/css" href="css/bootstrap-337.min.css">
<link rel="stylesheet" type="text/css" href="css/deliveries.css">

<html>
<body>
<h1> Driver Homepage </h1>
<br>
<div class="choose">
    <form method="POST" action='deliveries.php'>
        <label for="delivery_search"><h4> Please enter your <strong> DriverID </strong> number to view orders assigned to you: </h4></label>
        <input type='text' id='delivery_search' name='delivery_search' value="<?= $_SESSION['delivery_search'] ?>">
    <button type="submit" class="btn btn-primary btn-sm"> Get Orders </button>
    </form>
</div>

<!-- Create table with a row for every delivery that is not completed with checkbox in final column that will submit if complete -->
<div class="delivery_summary">
    <table>
        <th> DeliveryID</th>
        <th> DriverID</th>
        <th> Customer Address</th>
        <th> Contact Number </th>
        <th> Order Delivered</th>


        <?php
        /*If session is empty then nothing was inputted in search function and you dont use that to query*/
        if(!empty($_SESSION['delivery_search'])){
            $driver_id = "".$_SESSION['delivery_search']."";
            $query = "SELECT * from Delivery WHERE DeliveryCompleted='0' AND DriverID='$driver_id' ORDER BY DeliveryID ASC";
        }
        else{
            $query = "SELECT * from Delivery WHERE DeliveryCompleted='0' ORDER BY DeliveryID ASC";
        }

        //Check if nothin is returned, throw error if no rows are returned
        $sql_delivery = mysqli_query($conn, $query);
        if(mysqli_num_rows($sql_delivery) > 0) {
            while($row = mysqli_fetch_assoc($sql_delivery)){

                //Get Phone number of every person who has ordered by using delivery id to get customer ID to get phone
                $changing_delivery_id = "".$row['DeliveryID']."";
                $customer_query = "SELECT CustomerID from Orders WHERE DeliveryID ='$changing_delivery_id'";
                $do_customer = mysqli_query($conn, $customer_query);

                $customer_result = mysqli_fetch_assoc($do_customer);
                $customer_id = $customer_result["CustomerID"];

                $query = "SELECT PhoneNumber, Forename, Surname from Customer WHERE CustomerID ='$customer_id'";
                $do_query=mysqli_query($conn, $query);
                $phone_assoc = mysqli_fetch_assoc($do_query);

                ?>
                    <tr>
                    <td> <?php echo $row['DeliveryID'] ?></td>
                    <td> <?php echo $row['DriverID'] ?> </td>
                        <td> <?php echo nl2br($phone_assoc['Forename']." ".$phone_assoc['Surname'].",\n".
                                $row['HouseNumber']." ".$row['Street'].",\n".$row['Postcode'])?> </td>
                        <td> <?php echo $phone_assoc['PhoneNumber'] ?> </td>
                        <td>
                        <form method='POST' name='checker' id='checker <?php echo $i ?>' action='deliveries.php?delivery_ids=<?php echo $row["DeliveryID"] ?>'
                            <label>
                                <input type='checkbox' onchange='document.getElementById("checker <?php echo $i ?>").submit();'>
                            </label>
                            </form>
                        </td>
                    </tr>
                <?php $i++; }
            }
        else{
            $message = "That is not a valid DriverID. Please try again.";
        }
        ?>
        <p class="error_mes"> <?php echo $message ?></p>
    </table>
</div>

</body>
<footer>
</footer>
</html>

