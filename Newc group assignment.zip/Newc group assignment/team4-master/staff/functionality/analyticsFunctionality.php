<?php
// Written by Manon & Alice

include '../config/connect.php';

$conn = new mysqli($servername, $username, $password, $dbname);

$this_page = "analytics";
session_start();

// Set default timezone to London
date_default_timezone_set("Europe/London");

// Ensure that only logged in staff can view analytics
if ($_SESSION["staff_login"] === FALSE || !isset($_SESSION["staff_login"])) {
    header("Location: stafflogin.php");
    exit;
}

$staff_username = $_SESSION["staff_username"];

// Record current date for analytics start/end date limits
$current_date = date('Y-m-d');



// Find the total number of orders to display the flavour popularity as percentages (Manon)
$stmt_total = $conn->stmt_init();
if ($stmt_total = $conn->prepare("SELECT COUNT(OrderedItemID) FROM OrderedItem")) {
    $stmt_total->execute();
    $stmt_total->bind_result($total_ordered_items);
    $stmt_total->fetch();
    $stmt_total->close();
}

// Obtains the number of orders sold today (Alice)
$stmt_order1 = $conn->stmt_init();
if ($stmt_order1 = $conn->prepare("SELECT COUNT(OrderID) FROM Orders
                                       WHERE Orders.Date = ?")) {
    $stmt_order1->bind_param('s', $current_date);
    $stmt_order1->execute();
    $stmt_order1->bind_result($daily_number);
    $stmt_order1->fetch();
    $stmt_order1->close();
}

// Obtains the number of orders sold this week (Alice)
$stmt_order2 = $conn->stmt_init();
if ($stmt_order2 = $conn->prepare("SELECT COUNT(OrderID) FROM Orders
                                    WHERE WEEK(Date) = WEEK(CURDATE());")) {
    $stmt_order2->execute();
    $stmt_order2->bind_result($weekly_number);
    $stmt_order2->fetch();
    $stmt_order2->close();
}

// Obtains the number of orders sold this month (Alice)
$stmt_order3 = $conn->stmt_init();
if ($stmt_order3 = $conn->prepare("SELECT COUNT(OrderID) FROM Orders
                                       WHERE MONTH(Date) = MONTH(CURDATE());")) {
    $stmt_order3->execute();
    $stmt_order3->bind_result($monthly_number);
    $stmt_order3->fetch();
    $stmt_order3->close();
}

// For flavour popularity analytics: get the number of ordered items of each flavour (Manon)
$flavour_names = "";
$times_ordered = "";
$stmt_order = $conn->stmt_init();
if ($stmt_order = $conn->prepare("SELECT ProductFlavours.FlavourName, COUNT(OrderedItem.ProductQuantity) 
                                      FROM OrderedItem, ProductFlavours 
                                      WHERE ProductFlavours.FlavourID = OrderedItem.FlavourID 
                                      GROUP BY OrderedItem.FlavourID 
                                      ORDER BY COUNT(OrderedItem.ProductQuantity) DESC")) {
    $stmt_order->execute();
    $stmt_order->bind_result($flavour_names, $times_ordered);
    while ($stmt_order->fetch()) {
        $flavour_results[] = [
            'flavour_names' => $flavour_names,
            'times_ordered' => $times_ordered
        ];
    }
    $stmt_order->close();
}

// Returns the total number of orders in database (Manon)
$total_number_orders = "";
$stmt_total_orders = $conn->stmt_init();
if ($stmt_total_orders = $conn->prepare("SELECT COUNT(OrderID) FROM Orders")) {
    $stmt_total_orders->execute();
    $stmt_total_orders->bind_result($total_number_orders);
    $stmt_total_orders->fetch();
    $stmt_total_orders->close();
}

// Get the number of collection and delivery orders, and their percentages (Alice & Manon)
$collections_num = "";
$stmt_order5 = $conn->stmt_init();
if ($stmt_order5 = $conn->prepare("SELECT COUNT(OrderID) FROM Orders WHERE DeliveryID IS NULL;")) {
    $stmt_order5->execute();
    $stmt_order5->bind_result($collections_num);
    $stmt_order5->fetch();
    $stmt_order5->close();
}
$deliveries_num = $total_number_orders - $collections_num;
$deliveries_percentage = number_format(($deliveries_num / $total_number_orders) * 100, 2);
$collections_percentage = number_format(($collections_num / $total_number_orders) * 100, 2);


// Get an array of the number of orders for each day of the week (of all time) (Alice & Manon)
$stmt_order6 = $conn->stmt_init();
$orders = "";
$daily_frequency = [];
if ($stmt_order6 = $conn->prepare("SELECT COUNT(OrderID) FROM Orders
                                           GROUP BY DAYOFWEEK(Date);")) {
    $stmt_order6->execute();
    $stmt_order6->bind_result($orders);
    while ($stmt_order6->fetch()) {
        array_push($daily_frequency, $orders);
    }
    $stmt_order6->close();
}

// For viewing orders where the user can choose dates (Manon)
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $start_date = $_POST["start-date"];
    $end_date = $_POST["end-date"];
}

$orderID = "";
$customerID = "";
$deliveryID = "";
$total_price = "";
$time = "";
$date = "";
$transaction_accepted = "";
$order_results = [];
$stmt_order4 = $conn->stmt_init();
if ($stmt_order4 = $conn->prepare("SELECT * FROM Orders WHERE Date BETWEEN ? AND ?")) {
    $stmt_order4->bind_param('ss', $start_date, $end_date);
    $stmt_order4->execute();
    $stmt_order4->bind_result($orderID, $customerID, $deliveryID, $total_price, $time, $date, $transaction_accepted);
    while ($stmt_order4->fetch()) {
        $order_results[] = [
            'orderID' => $orderID,
            'customerID' => $customerID,
            'deliveryID' => $deliveryID,
            'total_price' => $total_price,
            'time' => $time,
            'date' => $date,
            'transaction_accepted' => $transaction_accepted
        ];
    }
    $stmt_order4->close();
}

$conn->close();
