<?php
include '../config/connect.php';
$this_page = "driverlogin";

session_start();
$_SESSION["driver_login"] = FALSE;
$this_page = "driverlogin";
$usernames = ["driver" => "vroomvroom"];
$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = filter_var($_POST["username"], FILTER_SANITIZE_STRING);
    $password = filter_var($_POST["password"], FILTER_SANITIZE_STRING);

    if (isset($usernames[$username]) && $usernames[$username] === $password) {
        $_SESSION["driver_login"] = TRUE;
        $_SESSION["driver_username"] = $username;
        $message = "Login successful";
        header("Location: deliveries.php");
        exit;
    } else {
        $message = "Please try again.";
    }
}
?>

<!DOCTYPE HTML>
<html lang="en">

<head>
    <title>Cavallo Driver Portal</title>
    <meta charset="utf-8">
    <link rel="icon" href="../public/img/favicon.png">
    <link rel="stylesheet" type="text/css" href="css/stafflogin.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-337.min.css">
</head>

<body>
<div class="col-md-4"></div>

<div class="col-md-4">
    <!-- col-md-4 Begin -->

    <div class="box">
        <!-- box Begin -->

        <div class="box-header">
            <!-- box-header Begin -->

            <center>
                <!-- center Begin -->

                <h1> Driver Login </h1><br>

            </center><!-- center Finish -->

            <form action="" method="post" enctype="multipart/form-data">
                <!-- form Begin -->

                <div class="form-group">
                    <!-- form-group Begin -->

                    <table>

                        <tr>

                            <td class="inputname"><label>Driver Username:</label></td>

                            <td class="inputvalue"><input type="text" class="form-control" name="username" required minlength=3 maxlength=30></td>

                        </tr>

                    </table>

                </div><!-- form-group Finish -->

                <div class="form-group">
                    <!-- form-group Begin -->

                    <table>

                        <tr>

                            <td class="inputname"><label>Password:</label></td>

                            <td class="inputvalue"><input type="password" class="form-control" name="password" required minlength=5 maxlength=20></td>

                        </tr>

                    </table>

                </div><!-- form-group Finish -->

                <div class="text-center">
                    <!-- text-center Begin -->

                    <button type="submit" name="Login" class="btn btn-primary">

                        <i class="fa fa-user-md"></i> Log in

                    </button>

                </div><!-- text-center Finish -->

            </form><!-- form Finish -->

            <div class="feedback">
                <p><?= $message; ?></p>
            </div><br>

            <center class="mention">
                <!-- center Begin -->

                <p> If there are any issue logging please contact the administrator at </p>
                <p> Team04@newcastle.ac.uk </p>

            </center><!-- center Finish -->

        </div><!-- box-header Finish -->

    </div><!-- box Finish -->

</div><!-- col-md-4 Finish -->
</body>

</html>
<?php
$conn->close(); // Close database connection
?>
