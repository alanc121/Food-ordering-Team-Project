<?php
// Writen by Manon & Alice
include 'functionality/analyticsFunctionality.php';
?>

<!DOCTYPE HTML>
<html lang="en">

<head>
    <title>Cavallo Staff</title>
    <meta charset="utf-8">
    <link rel="icon" href="../public/img/favicon.png">
    <link rel="stylesheet" type="text/css" href="css/analytics.css">
</head>


<body>

    <header>
        <div class="header-div">
            <div id="header-div-logo">
                <img src="../public/img/Cavallo.JPG" alt="Cavallo Logo" title="Cavallo Logo" width=240px height=110px>
            </div>
            <div id="header-div-title">
                <h1>Analytics dashboard</h1>
            </div>
            <div class="logout" id="header-div-logout">
                <form action="stafflogout.php" method="POST">
                    <input type="submit" value="Log out" aria-label="Log out button" id="logout-button">
                </form>
            </div>
    </header>

    <main>
        <div class="analytics_">
            <div class="number-of-orders">
                <h2>Order Summary</h2>
                <div class="order-figures">
                    <table class="order-table">
                        <tr>
                            <td>Orders today: </td>
                            <td><?php echo $daily_number; ?></td>
                            <td>Orders this week: </td>
                            <td><?php echo $weekly_number; ?></td>
                            <td>Orders this month: </td>
                            <td><?php echo $monthly_number; ?></td>
                        </tr>
                    </table>
                </div>

            </div>
        </div>
        <div class="simple-analytics">
            <div class="analytics-flavour-popularity">
                <!-- Manon -->
                <div class="flavour-popularity">
                    <h2>Popularity Of Flavours</h2>
                    <div class="flavour-figures">
                        <table class="flavour-popularity-table">
                            <?php
                            $flavour_names_arr = [];
                            $flavour_values_arr = [];
                            foreach ($flavour_results as $index => $row) {
                                array_push($flavour_names_arr, $row['flavour_names']);
                                array_push($flavour_values_arr, $row['times_ordered']);
                                $ranking = $index + 1;
                                $percentage = ($row['times_ordered'] / $total_ordered_items) * 100;
                                $percentage = number_format($percentage, 2); // Show percentages to two decimal places
                                echo '<tr>';
                                echo '<td>' . '#' . $ranking . '</td>';
                                echo '<td>' . $row['flavour_names'] . '</td>';
                                echo '<td>' . $percentage . '%' . '</td>';
                                echo '</tr>';
                            }
                            ?>
                        </table>
                        <canvas id="flavour-popularity-chart-canvas" height=225px></canvas>
                    </div>
                </div>
            </div>
            <div class="analytics-delivery-vs-collection">
                <div class="delivery-vs-collection">
                    <div class="comparison">
                        <h2>Delivery vs Collection</h2>
                        <div class="order-figures">
                            <table class="delivery-collection-table">
                                <tr>
                                    <td>Orders placed for collection: </td>
                                    <td><?= $collections_num ?></td>
                                    <td><?= $collections_percentage . "%" ?></td>
                                </tr>
                                <tr>
                                    <td>Orders placed for delivery:</td>
                                    <td><?= $deliveries_num ?></td>
                                    <td><?= $deliveries_percentage . "%" ?></td>
                                </tr>
                            </table>
                            <div class="daily-orders-chart">
                                <canvas id="delivery-collection-chart-canvas" width=200px, height=200px></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <br>

        <div class="days-of-week">
            <h2> The total number of orders for each day of the week</h2>
            <?php
            //$daily_frequency;
            ?>
            <div class="orders-each-day">
                <table class="daily-orders-table">
                    <tr>
                        <td>Monday: </td>
                        <td><?php echo $daily_frequency[1]; ?></td>
                        <td>Tuesday: </td>
                        <td><?php echo $daily_frequency[2]; ?></td>
                        <td>Wednesday: </td>
                        <td><?php echo $daily_frequency[3]; ?></td>
                        <td>Thursday: </td>
                        <td><?php echo $daily_frequency[4]; ?></td>
                        <td>Friday: </td>
                        <td><?php echo $daily_frequency[5]; ?></td>
                        <td>Saturday: </td>
                        <td><?php echo $daily_frequency[6]; ?></td>
                        <td>Sunday: </td>
                        <td><?php echo $daily_frequency[0]; ?></td>
                    </tr>
                </table>
            </div>
            <div class="daily-orders-chart">
                <canvas id="daily-orders-chart-canvas" width=400px, height=300px></canvas>
            </div>
        </div>

        <br>
        <br>

        <div class="advanced-analytics">
            <h2>View orders</h2>
            <div class="choose-display-options">
                <h3>Choose date range</h3>
                <form method="POST">
                    <label for="start-date">Start date</label>
                    <!-- placeholder attribute is for Safari which does not support date forms -->
                    <input type="date" placeholder="yyyy-mm-dd" name="start-date" id="start-date" min="2020-01-01" max="<?= $current_date ?>">
                    <label for="end-date">End date</label>
                    <input type="date" placeholder="yyyy-mm-dd" name="end-date" id="end-date" min="2020-01-01" max="<?= $current_date ?>">
                    <input type="submit" value="Enter" id="enter-button">
                </form>
            </div>
            <br>
            <div class="display-statistics">
                <div class='display-statistics-orders'>
                    <table class="display-statistics-orders-table">
                        <tr>
                            <td>Order ID</td>
                            <td>Customer ID</td>
                            <td>Delivery ID</td>
                            <td>Total Price</td>
                            <td>Time</td>
                            <td>Date</td>
                            <td>Transaction accepted</td>
                        </tr>
                        <?php
                        foreach ($order_results as $row) {
                            echo '<tr>';
                            echo '<td>' . $row['orderID'] . '</td>';
                            echo '<td>' . $row['customerID'] . '</td>';
                            echo '<td>' . $row['deliveryID'] . '</td>';
                            echo '<td>' . '£ ' . $row['total_price'] . '</td>';
                            echo '<td>' . $row['time'] . '</td>';
                            echo '<td>' . $row['date'] . '</td>';
                            if ($row['transaction_accepted'] === 1) {
                                echo '<td>' . 'Yes' . '</td>';
                            } else {
                                echo '<td>' . 'No' . '</td>';
                            }
                        }
                        ?>
                    </table>
                </div>
            </div>
        </div>

    </main>

    <footer>

    </footer>

</body>

</html>

<!-- Charts using Chart.js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.min.js"></script>

<!-- Flavour popularity horizontal bar chart -->
<script>
    var ctx = document.getElementById('flavour-popularity-chart-canvas');
    var flavourNames = <?php echo json_encode($flavour_names_arr); ?>;
    var flavourValues = <?php echo json_encode($flavour_values_arr); ?>;
    var flavourChart = new Chart(ctx, {
        type: 'horizontalBar',
        data: {
            labels: flavourNames,
            datasets: [{
                label: "# of times ordered",
                data: flavourValues,
                backgroundColor: ['rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)'
                ],
                borderWidth: 1
            }],
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            }
        }
    })
</script>

<!-- Day of the week order frequency chart -->
<script>
    var ctx = document.getElementById('daily-orders-chart-canvas');
    var dailyData = <?php echo json_encode($daily_frequency); ?>;
    var myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
            datasets: [{
                label: '# of Orders',
                data: [dailyData[1],
                    dailyData[2],
                    dailyData[3],
                    dailyData[4],
                    dailyData[5],
                    dailyData[6],
                    dailyData[0]
                ],
                backgroundColor: ['rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            }
        }
    });
</script>

<!-- Delivery/Collection pie chart -->
<script>
    var ctx = document.getElementById('delivery-collection-chart-canvas');
    var collectionData = <?php echo $collections_num ?>;
    var deliveryData = <?php echo $deliveries_num ?>;
    var myPieChart = new Chart(ctx, {
        type: 'pie',
        data: {
            datasets: [{
                data: [collectionData, deliveryData],
                backgroundColor: ['rgba(255, 0, 0, 0.2)', 'rgba(255, 0, 0, 0.4)']
            }],
            labels: ['Collection', 'Delivery']
        },
    });
</script>